/* mod-hostserv.c - HostServ module for srvx
 * Copyright 2012-2013 pk910, Stricted, NurPech
 *
 * This file is part of srvx.
 *
 * srvx is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with srvx; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 */

/* Adds new section to srvx.conf:
 * "modules" {
 *     "hostserv" {
 *         "nick" "HostServ";
 *         "modes" "+iok";
 *         "toplevel_access" "600";
 *         "fallback_other_assignment" "1"; //fall back to another assignment when active assignment gets removed
 *         "manager_can_rename_toplevel" "0"; //managers of a toplevel group may rename the whole group
 *         "manager_can_del_toplevel" "0"; //managers of a toplevel group may delete the whole group
 *         "manager_can_rename_secondlevel" "0"; //managers of a secondlevel group may rename the whole group
 *         "manager_can_del_secondlevel" "0"; //managers of a secondlevel group may delete the whole group
 *         "manager_toplevel_can_oset" "0"; //managers of a toplevel group can set other user's fakehosts
 *         "manager_secondlevel_can_oset" "0"; //managers of a secondlevel group can set other user's fakehosts
 *     };
 *  };
 *
 * After you started srvx make the bot active:
 /msg opserv bind hostserv * hostserv.*
 /msg opserv bind hostserv help *modcmd.help
 */

#include "chanserv.h"
#include "opserv.h"
#include "nickserv.h"
#include "conf.h"
#include "modcmd.h"
#include "saxdb.h"
#include "timeq.h"

#define KEY_TOPLEVEL "TopLevel"
#define KEY_SECONDLEVEL "SecondLevel"
#define KEY_MANAGERS "Manager"
#define KEY_ASSIGNMENTS "Assignments"
#define KEY_ACTIVE "active"

#define HS_FAKEHOST_SPECIAL_CHARS "_-:;" /* alphanum already included */

#define HS_ASSIGNMENTSTATE_AUTO -1
#define HS_ASSIGNMENTSTATE_OFF  0
#define HS_ASSIGNMENTSTATE_ON   1

#define HS_FHPARSE_SUCCESS 0
#define HS_FHPARSE_INVALID 1
#define HS_FHPARSE_UNKNOWN 2

static const struct message_entry msgtab[] = {
    { "HSMSG_ACCESS_DENIED", "Access denied." },
    { "HSMSG_ASSIGNED_FAKEHOSTS", "Assigned Fakehosts for User $b%s$b:" },
    { "HSMSG_ASSIGNED_FAKEHOST", "  $b%s.%s$b" },
    { "HSMSG_ASSIGNED_FAKEHOST_ACTTIVE", "  $b%s.%s$b (active)" },
    { "HSMSG_ASSIGNED_FAKEHOST_NOT_ACTIVE", "Fakehost $b%s.%s.$b is not active." },
    { "HSMSG_ASSIGN_HOWTO", "Use $bset xxx.yyy$b to activate one of the listed fakehosts or $bset *$b to use the default fakehost." },
    { "HSMSG_ASSIGNED_NONE", "  None." },
    { "HSMSG_MANAGED_FAKEHOSTS", "Fakehosts managed by User $b%s$b:" },
    { "HSMSG_MANAGED_TOPLEVEL", "  $b*.%s$b   fakehosts: %d   assignments: %d" },
    { "HSMSG_MANAGED_TOPLEVEL_OWN", "  $b*.%s$b   fakehosts: %d   assignments: %d   (active)" },
    { "HSMSG_MANAGED_FAKEHOST", "  $b%s.%s$b   assignments: %d" },
    { "HSMSG_MANAGE_HOWTO", "Use $bview xxx.yyy$b to view more information about a fakehost group." },
    { "HSMSG_UNKNOWN_FAKEHOST", "Fakehost $b%s.%s$b is unknown or you have no access to manage it." },
    { "HSMSG_TOPLEVEL_FAKEHOSTS", "Fakehosts in group $b*.%s$b:" },
    { "HSMSG_TOPLEVEL_FAKEHOST", "  $b%s.%s$b   assignments: %d   managers: %d" },
    { "HSMSG_TOPLEVEL_INVALID", "The name of the group you entered is invalid ($b%s$b)" },
    { "HSMSG_MANAGERS_TOPLEVEL", "Managers of group $b*.%s$b:" },
    { "HSMSG_MANAGERS_FAKEHOST", "Managers of group $b%s.%s$b:" },
    { "HSMSG_MANAGERS_MANAGERS", "  %s" },
    { "HSMSG_FAKEHOST_ASSIGNMENTS", "Assignments in group $b%s.%s$b:" },
    { "HSMSG_FAKEHOST_ASSIGNMENT", "  $b%s$b (%s.%s.%s)" },
    { "HSMSG_FAKEHOST_ASSIGNMENT_ACTIVE", "  $b%s$b (%s.%s.%s)   active" },
    { "HSMSG_FAKEHOST_SET_SUCCESS", "$b%s.%s$b where set successfully." },
    { "HSMSG_FAKEHOST_TOPLEVEL_ADDED", "Group $b%s$b successfully added." },
    { "HSMSG_FAKEHOST_TOPLEVEL_ALREADY_EXISTS", "Group $b%s$b already exists." },
    { "HSMSG_FAKEHOST_TOPLEVEL_DELETED", "Group $b%s$b successfully deleted." },
    { "HSMSG_FAKEHOST_SECONDLEVEL_ADDED", "Group $b%s.%s$b successfully added." },
    { "HSMSG_FAKEHOST_SECONDLEVEL_ALREADY_EXISTS", "Group $b%s.%s$b already exists." },
    { "HSMSG_FAKEHOST_SECONDLEVEL_DELETED", "Group $b%s.%s$b successfully deleted." },
    { "HSMSG_FAKEHOST_RENAMED", "Group $b%s.%s$b renamed to $b%s.%s$b." },
    { "HSMSG_MANAGER_ALREADY", "$b%s$b is already a manager of %s.%s" },
    { "HSMSG_MANAGER_ADDED", "$b%s$b is now a manager of %s.%s" },
    { "HSMSG_MANAGER_NOT", "$b%s$b is not a manager of %s.%s" },
    { "HSMSG_MANAGER_DELETED", "$b%s$b is no longer a manager of %s.%s" },
    { "HSMSG_FAKEHOST_ASSIGN_SUCCESS", "Group $b%s.%s$b was assigned successfully." },
    { "HSMSG_FAKEHOST_ASSIGNED", "Group $b%s.%s$b is already assigned to the user." },
    { "HSMSG_FAKEHOST_UNASSIGN_SUCCESS", "Group $b%s.%s$b was unassigned successfully." },
    
    { NULL, NULL }
};

static struct {
    const char *nick;
    const char *modes;
    int toplevel_access;
    int fallback_other_assignment : 1;
    int manager_can_del_toplevel : 1;
    int manager_can_del_secondlevel : 1;
    int manager_can_rename_toplevel : 1;
    int manager_can_rename_secondlevel : 1;
    int manager_toplevel_can_oset : 1;
    int manager_secondlevel_can_oset : 1;
} hostserv_conf;

const char *hostserv_module_deps[] = { NULL };
struct userNode *hostserv;
struct helpfile *hostserv_helpfile;
static struct module *hostserv_module;
static struct service *hostserv_service;
static struct log_type *HS_LOG;
static struct hs_toplevel *toplevels = NULL;
static struct hs_user *hostserv_users = NULL;

/* FAKEHOST STRUCTS */
struct hs_toplevel {
    char *fakehost;
    struct hs_manager *managers;
    struct hs_secondlevel *secondlevel;
    struct hs_toplevel *next;
};

struct hs_secondlevel {
    struct hs_toplevel *toplevel;
    char *fakehost;
    struct hs_manager *managers;
    struct hs_assignment *assignments;
    struct hs_secondlevel *next;
};

struct hs_assignment {
    struct hs_secondlevel *secondlevel;
    struct hs_user *user;
    int active;
    struct hs_assignment *next;
    struct hs_assignment *unext; /* for hs_user */
};

struct hs_manager {
    char type;
    void *object;
    int active;
    struct hs_user *user;
    struct hs_manager *next;
    struct hs_manager *unext; /* for hs_user */
};

struct hs_user {
    struct handle_info *hi;
    struct hs_assignment *assignments;
    struct hs_manager *managements;
    struct hs_user *next;
};

/* temporary structs */
struct hs_fakehost_info {
    unsigned int parse_state : 4;
    unsigned int have_secondlevel : 1;
    char *tlfh_name;
    char *slfh_name;
    struct hs_toplevel *tlfh;
    struct hs_secondlevel *slfh;
};

/* MANAGEMENT FUNCTIONS for FAKEHOST STRUCTS */
static void hs_del_secondlevel(struct hs_secondlevel *slfh, int remove_from_tlfh);
static void hs_del_manager(struct hs_manager *manager, int remove_from_object);
static void hs_del_assignment(struct hs_assignment *assignment, int remove_from_slfh);
static void hs_del_user(struct hs_user *user);
static void hs_activate_assignment(struct hs_user *user, struct hs_assignment *assignment);

static void hs_free_all() {
    struct hs_toplevel *tlfh, *next_tlfh;
    struct hs_secondlevel *slfh, *next_slfh;
    struct hs_assignment *assng, *next_assng;
    struct hs_manager *manager, *next_manager;
    struct hs_user *user, *next_user;
    for(tlfh = toplevels; tlfh; tlfh = next_tlfh) {
        next_tlfh = tlfh->next;
        for(manager = tlfh->managers; manager; manager = next_manager) {
            next_manager = manager->next;
            free(manager);
        }
        for(slfh = tlfh->secondlevel; slfh; slfh = next_slfh) {
            next_slfh = slfh->next;
            for(manager = slfh->managers; manager; manager = next_manager) {
                next_manager = manager->next;
                free(manager);
            }
            for(assng = slfh->assignments; assng; assng = next_assng) {
                next_assng = assng->next;
                free(assng);
            }
            free(slfh->fakehost);
            free(slfh);
        }
        free(tlfh->fakehost);
        free(tlfh);
    }
    for(user = hostserv_users; user; user = next_user) {
        next_user = user->next;
        free(user);
    }
    toplevels = NULL;
    hostserv_users = NULL;
}

static struct hs_toplevel *hs_add_toplevel(const char *name) {
    struct hs_toplevel *tlfh = calloc(1, sizeof(*tlfh));
    tlfh->fakehost = strdup(name);
    tlfh->next = toplevels;
    toplevels = tlfh;
    return tlfh;
}

static void hs_del_toplevel(struct hs_toplevel *tlfh) {
    //unassign all assignments
    struct hs_secondlevel *slfh, *next_slfh;
    struct hs_manager *manager, *next_manager;
    for(manager = tlfh->managers; manager; manager = next_manager) {
        next_manager = manager->next;
        hs_del_manager(manager, 0);
    }
    for(slfh = tlfh->secondlevel; slfh; slfh = next_slfh) {
        next_slfh = slfh->next;
        hs_del_secondlevel(slfh, 0);
    }
    
    struct hs_toplevel *ctlfh, *last_tlfh = NULL;
    for(ctlfh = toplevels; ctlfh; ctlfh = ctlfh->next) {
        if(ctlfh == tlfh) {
            if(last_tlfh)
                last_tlfh->next = ctlfh->next;
            else
                toplevels = ctlfh->next;
        } else
            last_tlfh = ctlfh;
    }
    free(tlfh->fakehost);
    free(tlfh);
}

static void hs_rename_toplevel(struct hs_toplevel *tlfh, const char *name) {
    struct hs_secondlevel *slfh;
    struct hs_assignment *assng;
    
    free(tlfh->fakehost);
    tlfh->fakehost = strdup(name);
    
    //trigger rename for all assignments
    for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
        for(assng = slfh->assignments; assng; assng = assng->next) {
            if(assng->active) {
                hs_activate_assignment(assng->user, assng);
            }
        }
    }
}

static struct hs_secondlevel *hs_add_secondlevel(struct hs_toplevel *tlfh, const char *name) {
    struct hs_secondlevel *slfh = calloc(1, sizeof(*slfh));
    slfh->toplevel = tlfh;
    slfh->fakehost = strdup(name);
    slfh->next = tlfh->secondlevel;
    tlfh->secondlevel = slfh;
    return slfh;
}

static void hs_del_secondlevel(struct hs_secondlevel *slfh, int remove_from_tlfh) {
    if(remove_from_tlfh) {
        struct hs_secondlevel *cslfh, *prev_slfh = NULL;
        for(cslfh = slfh->toplevel->secondlevel; cslfh; cslfh = cslfh->next) {
            if(cslfh == slfh) {
                if(prev_slfh)
                    prev_slfh->next = slfh->next;
                else
                    slfh->toplevel->secondlevel = slfh->next;
                break;
            } else
                prev_slfh = cslfh;
        }
    }
    struct hs_assignment *assng, *next_assng;
    struct hs_manager *manager, *next_manager;
    for(manager = slfh->managers; manager; manager = next_manager) {
        next_manager = manager->next;
        hs_del_manager(manager, 0);
    }
    for(assng = slfh->assignments; assng; assng = next_assng) {
        next_assng = assng->next;
        hs_del_assignment(assng, 0);
    }
    free(slfh->fakehost);
    free(slfh);
}

static void hs_rename_secondlevel(struct hs_secondlevel *slfh, const char *name) {
    struct hs_assignment *assng;
    
    free(slfh->fakehost);
    slfh->fakehost = strdup(name);
    
    //trigger rename for all assignments
    for(assng = slfh->assignments; assng; assng = assng->next) {
        if(assng->active) {
            hs_activate_assignment(assng->user, assng);
        }
    }
}

static struct hs_manager *hs_add_manager_toplevel(struct hs_toplevel *tlfh, struct hs_user *user) {
    struct hs_manager *manager = calloc(1, sizeof(*manager));
    manager->user = user;
    manager->type = 1;
    manager->object = tlfh;
    manager->unext = user->managements;
    user->managements = manager;
    manager->next = tlfh->managers;
    tlfh->managers = manager;
    return manager;
}

static struct hs_manager *hs_add_manager_secondlevel(struct hs_secondlevel *slfh, struct hs_user *user) {
    struct hs_manager *manager = calloc(1, sizeof(*manager));
    manager->user = user;
    manager->type = 2;
    manager->object = slfh;
    manager->unext = user->managements;
    user->managements = manager;
    manager->next = slfh->managers;
    slfh->managers = manager;
    return manager;
}

static void hs_del_manager(struct hs_manager *manager, int remove_from_object) {
    struct hs_manager *cmanager, *prev_manager = NULL;
    if(remove_from_object) {
        if(manager->type == 1) {
            struct hs_toplevel *tlfh = manager->object;
            for(cmanager = tlfh->managers; cmanager; cmanager = cmanager->next) {
                if(cmanager == manager) {
                    if(prev_manager)
                        prev_manager->next = manager->next;
                    else
                        tlfh->managers = manager->next;
                    break;
                } else
                    prev_manager = cmanager;
            }
        } else if(manager->type == 2) {
            struct hs_secondlevel *slfh = manager->object;
            for(cmanager = slfh->managers; cmanager; cmanager = cmanager->next) {
                if(cmanager == manager) {
                    if(prev_manager)
                        prev_manager->next = manager->next;
                    else
                        slfh->managers = manager->next;
                    break;
                } else
                    prev_manager = cmanager;
            }
        }
        prev_manager = NULL;
    }
    if(remove_from_object != 2) {
        for(cmanager = manager->user->managements; cmanager; cmanager = cmanager->unext) {
            if(cmanager == manager) {
                if(prev_manager)
                    prev_manager->unext = manager->unext;
                else
                    manager->user->managements = manager->unext;
                break;
            } else
                prev_manager = cmanager;
        }
        if(manager->user->managements == NULL && manager->user->assignments == NULL)
            hs_del_user(manager->user);
    }
    free(manager);
}

static void hs_activate_assignment(struct hs_user *user, struct hs_assignment *assignment) {
    struct hs_toplevel *tlfh;
    struct hs_secondlevel *slfh;
    struct hs_assignment *assgn;
    char fakehost[HOSTLEN];
    
    assert((!assignment || (assignment->user == user)));
    
    if(user->assignments) {
        for(assgn = user->assignments; assgn; assgn = assgn->unext)
            assgn->active = 0;
    }
    
    if(user->hi->fakehost) {
        free(user->hi->fakehost);
        user->hi->fakehost = NULL;
    }
    
    if(assignment) {
        slfh = assignment->secondlevel;
        tlfh = slfh->toplevel;
        snprintf(fakehost, sizeof(fakehost), "$.%s.%s", slfh->fakehost, tlfh->fakehost);
        user->hi->fakehost = strdup(fakehost);
        assignment->active = 1;
    }
    
    apply_fakehost(user->hi, NULL);
}

static struct hs_assignment *hs_add_assignment(struct hs_secondlevel *slfh, struct hs_user *user, int active) {
    struct hs_assignment *assignment = calloc(1, sizeof(*assignment));
    assignment->secondlevel = slfh;
    assignment->user = user;
    if(active == HS_ASSIGNMENTSTATE_AUTO)
        assignment->active = (user->assignments == NULL ? 1 : 0);
    else
        assignment->active = (active == HS_ASSIGNMENTSTATE_ON ? 1 : 0);
    assignment->next = slfh->assignments;
    slfh->assignments = assignment;
    assignment->unext = user->assignments;
    user->assignments = assignment;
    if(assignment->active) {
        hs_activate_assignment(user, assignment);
    }
    return assignment;
}

static void hs_del_assignment(struct hs_assignment *assignment, int remove_from_slfh) {
    struct hs_assignment *cassignment, *prev_assignment = NULL;
    if(remove_from_slfh) {
        for(cassignment = assignment->secondlevel->assignments; cassignment; cassignment = cassignment->next) {
            if(cassignment == assignment) {
                if(prev_assignment)
                    prev_assignment->next = assignment->next;
                else
                    assignment->secondlevel->assignments = assignment->next;
                break;
            } else
                prev_assignment = cassignment;
        }
        prev_assignment = NULL;
    }
    if(remove_from_slfh != 2) {
        prev_assignment = NULL;
        for(cassignment = assignment->user->assignments; cassignment; cassignment = cassignment->unext) {
            if(cassignment == assignment) {
                if(prev_assignment)
                    prev_assignment->unext = assignment->unext;
                else
                    assignment->user->assignments = assignment->unext;
                break;
            } else
                prev_assignment = cassignment;
        }
        
        if(assignment->active) {
            /* use another assignment - or fall back to default user host? */
            cassignment = NULL;
            if(hostserv_conf.fallback_other_assignment && assignment->user->assignments) {
                /* try to find another assignment from same slfh first */
                for(cassignment = assignment->secondlevel->assignments; cassignment; cassignment = cassignment->next) {
                    if(cassignment != assignment && cassignment->user == assignment->user)
                        break;
                }
                /* use another tlfh assignment */
                if(!cassignment)
                    cassignment = assignment->user->assignments;
            }
            hs_activate_assignment(assignment->user, cassignment);
        }
        
        if(assignment->user->managements == NULL && assignment->user->assignments == NULL)
            hs_del_user(assignment->user);
    }
    free(assignment);
}

static struct hs_assignment *hs_get_assignment(struct hs_secondlevel *slfh, struct hs_user *user) {
    struct hs_assignment *cassignment;
    for(cassignment = slfh->assignments; cassignment; cassignment = cassignment->next) {
        if(cassignment->user == user)
            return cassignment;
    }
    return NULL;
}

static struct hs_user *hs_get_user(struct handle_info *hi, int create) {
    struct hs_user *cuser;
    for(cuser = hostserv_users; cuser; cuser = cuser->next) {
        if(cuser->hi == hi)
            return cuser;
    }
    if(create) {
        cuser = calloc(1, sizeof(*cuser));
        cuser->hi = hi;
        cuser->next = hostserv_users;
        hostserv_users = cuser;
        return cuser;
    } else
        return NULL;
}

static void hs_del_user(struct hs_user *user) {
    if(user->managements) {
        struct hs_manager *manager, *next_manager;
        for(manager = user->managements; manager; manager = next_manager) {
            next_manager = manager->unext;
            hs_del_manager(manager, 2);
        }
    }
    if(user->assignments) {
        struct hs_assignment *assng, *next_assng;
        for(assng = user->assignments; assng; assng = next_assng) {
            next_assng = assng->unext;
            hs_del_assignment(assng, 2);
        }
    }
    struct hs_user *cuser, *prev_user = NULL;
    for(cuser = hostserv_users; cuser; cuser = cuser->next) {
        if(cuser == user) {
            if(prev_user)
                prev_user->next = user->next;
            else
                hostserv_users = user->next;
            break;
        } else
            prev_user = cuser;
    }
    free(user);
}

/* END OF MANAGEMENT FUNCTIONS */

static int check_management_access(struct handle_info *hi, struct hs_toplevel *tlfh, struct hs_secondlevel *slfh) {
    if(!hi) 
        return 0;
    if(hi->opserv_level >= hostserv_conf.toplevel_access) 
        return 1;
    struct hs_user *user = hs_get_user(hi, 0);
    if(!user)
        return 0;
    struct hs_manager *manager;
    if(slfh) {
        for(manager = user->managements; manager; manager = manager->next) {
            if(manager->type == 2 && manager->object == slfh) 
                return 1;
        }
    }
    if(tlfh) {
        for(manager = user->managements; manager; manager = manager->next) {
            if(manager->type == 1 && manager->object == tlfh) 
                return 1;
        }
    }
    return 0;
}

struct hs_fakehost_info parse_fakehost_info(char *fakehost, int fix_name_case) {
    struct hs_fakehost_info fhinfo;
    int i;
    memset(&fhinfo, 0, sizeof(fhinfo));
    for(i = strlen(fakehost)-1; i >= 0; i--) {
        if(!isalnum(fakehost[i]) && fakehost[i] != '.' && !(fakehost[i] == '*' && i == 0) && !strchr(HS_FAKEHOST_SPECIAL_CHARS, fakehost[i])) {
            fhinfo.parse_state = HS_FHPARSE_INVALID;
            return fhinfo;
        }
    }
    fhinfo.slfh_name = fakehost;
    fhinfo.tlfh_name = strchr(fakehost, '.');
    if(!fhinfo.tlfh_name) {
        fhinfo.parse_state = HS_FHPARSE_INVALID;
        return fhinfo;
    }
    fhinfo.tlfh_name[0] = '\0';
    fhinfo.tlfh_name++;
    if(strchr(fhinfo.tlfh_name, '.')) {
        fhinfo.parse_state = HS_FHPARSE_INVALID;
        fhinfo.tlfh_name--;
        fhinfo.tlfh_name[0] = '\0';
        return fhinfo;
    }
    if(irccasecmp(fhinfo.slfh_name, "*"))
        fhinfo.have_secondlevel = 1;
    struct hs_toplevel *tlfh;
    struct hs_secondlevel *slfh;
    for(tlfh = toplevels; tlfh; tlfh = tlfh->next) {
        if(!irccasecmp(tlfh->fakehost, fhinfo.tlfh_name)) break;
    }
    fhinfo.tlfh = tlfh;
    if(!tlfh) {
        fhinfo.slfh = NULL;
        fhinfo.parse_state = HS_FHPARSE_UNKNOWN;
        return fhinfo;
    }
    if(fhinfo.have_secondlevel) {
        for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
            if(!irccasecmp(slfh->fakehost, fhinfo.slfh_name)) break;
        }
        fhinfo.slfh = slfh;
        if(!slfh) {
            fhinfo.parse_state = HS_FHPARSE_UNKNOWN;
            return fhinfo;
        }
    } else
        fhinfo.slfh = NULL;
    if(fix_name_case) {
        //simply copy the stored fakehosts over the given ones
        strcpy(fhinfo.tlfh_name, fhinfo.tlfh->fakehost);
        if(fhinfo.slfh)
            strcpy(fhinfo.slfh_name, fhinfo.slfh->fakehost);
    }
    fhinfo.parse_state = HS_FHPARSE_SUCCESS;
    return fhinfo;
}



static void cmd_view_toplevel_information(UNUSED_ARG(struct userNode *user), UNUSED_ARG(struct svccmd *cmd), struct hs_toplevel *tlfh) {
    reply("HSMSG_TOPLEVEL_FAKEHOSTS", tlfh->fakehost);
    struct hs_secondlevel *slfh;
    if(!tlfh->secondlevel)
        reply("HSMSG_ASSIGNED_NONE");
    else
    for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
        struct hs_manager *cmanager;
        int managers = 0;
        for(cmanager = slfh->managers; cmanager; cmanager = cmanager->next)
            managers++;
        struct hs_assignment *assignment;
        int assignments = 0;
        for(assignment = slfh->assignments; assignment; assignment = assignment->next)
            assignments++;
        reply("HSMSG_TOPLEVEL_FAKEHOST", slfh->fakehost, tlfh->fakehost, assignments, managers);
    }
    reply("HSMSG_MANAGERS_TOPLEVEL", tlfh->fakehost);
    struct hs_manager *cmanager;
    if(!tlfh->managers)
        reply("HSMSG_ASSIGNED_NONE");
    else {
        char managerBuf[351];
        int managerPos = 0;
        for(cmanager = tlfh->managers; cmanager; cmanager = cmanager->next) {
            if(managerPos + strlen(cmanager->user->hi->handle) + 2 >= 350) {
                reply("HSMSG_MANAGERS_MANAGERS", managerBuf);
                managerPos = 0;
            }
            managerPos += sprintf(managerBuf + managerPos, (managerPos ? ", %s" : "%s"), cmanager->user->hi->handle);
        }
        reply("HSMSG_MANAGERS_MANAGERS", managerBuf);
    }
}

static void cmd_view_secondlevel_information(UNUSED_ARG(struct userNode *user), UNUSED_ARG(struct svccmd *cmd), struct hs_secondlevel *slfh) {
    reply("HSMSG_FAKEHOST_ASSIGNMENTS", slfh->fakehost, slfh->toplevel->fakehost);
    struct hs_assignment *assignment;
    for(assignment = slfh->assignments; assignment; assignment = assignment->next) {
        reply((assignment->active ? "HSMSG_FAKEHOST_ASSIGNMENT_ACTIVE" : "HSMSG_FAKEHOST_ASSIGNMENT"), assignment->user->hi->handle, assignment->user->hi->handle, slfh->fakehost, slfh->toplevel->fakehost);
    }
    reply("HSMSG_MANAGERS_FAKEHOST", slfh->fakehost, slfh->toplevel->fakehost);
    struct hs_manager *cmanager;
    if(!slfh->managers)
        reply("HSMSG_ASSIGNED_NONE");
    else {
        char managerBuf[351];
        int managerPos = 0;
        for(cmanager = slfh->managers; cmanager; cmanager = cmanager->next) {
            if(managerPos + strlen(cmanager->user->hi->handle) + 2 >= 350) {
                reply("HSMSG_MANAGERS_MANAGERS", managerBuf);
                managerPos = 0;
            }
            managerPos += sprintf(managerBuf + managerPos, (managerPos ? ", %s" : "%s"), cmanager->user->hi->handle);
        }
        reply("HSMSG_MANAGERS_MANAGERS", managerBuf);
    }
}

static MODCMD_FUNC(cmd_view) {
    struct handle_info *hi;
    if(argc >= 2 && !strchr(argv[1], '.')) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
    } else if(argc >= 2) {
        if (!(hi = user->handle_info)) {
            reply("NSMSG_MUST_AUTH");
            return 0;
        }
        struct hs_fakehost_info fhinfo = parse_fakehost_info(argv[1], 0);
        if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
            reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
            return 0;
        } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
            reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        if(!fhinfo.slfh) {
            if(!check_management_access(hi, fhinfo.tlfh, NULL)) {
                reply("HSMSG_ACCESS_DENIED");
                return 0;
            }
            cmd_view_toplevel_information(user, cmd, fhinfo.tlfh);
            return 1;
        } else {
            if(!check_management_access(hi, fhinfo.tlfh, fhinfo.slfh)) {
                reply("HSMSG_ACCESS_DENIED");
                return 0;
            }
            cmd_view_secondlevel_information(user, cmd, fhinfo.slfh);
            return 1;
        }
    } else {
        if (!(hi = user->handle_info)) {
            reply("NSMSG_MUST_AUTH");
            return 0;
        }
    }
    struct hs_user *huser = hs_get_user(hi, 0);
    reply("HSMSG_ASSIGNED_FAKEHOSTS", hi->handle);
    int assigncount = 0;
    if(huser) {
        struct hs_assignment *assignment;
        for(assignment = huser->assignments; assignment; assignment = assignment->unext) {
            reply((assignment->active ? "HSMSG_ASSIGNED_FAKEHOST_ACTTIVE" : "HSMSG_ASSIGNED_FAKEHOST"), assignment->secondlevel->fakehost, assignment->secondlevel->toplevel->fakehost);
            assigncount++;
        }
        if(assigncount && huser->hi == user->handle_info)
            reply("HSMSG_ASSIGN_HOWTO");
    }
    if(!assigncount)
        reply("HSMSG_ASSIGNED_NONE");
    if(user->handle_info == hi && hi->opserv_level >= hostserv_conf.toplevel_access) {
        struct hs_toplevel *tlfh;
        for(tlfh = toplevels; tlfh; tlfh = tlfh->next) {
            struct hs_secondlevel *slfh;
            struct hs_assignment *assignment;
            int slfhs = 0, assignments = 0;
            for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
                slfhs++;
                for(assignment = slfh->assignments; assignment; assignment = assignment->next)
                    assignments++;
            }
            reply("HSMSG_MANAGED_TOPLEVEL", tlfh->fakehost, slfhs, assignments);
        }
        reply("HSMSG_MANAGE_HOWTO");
    } else if(huser && huser->managements) {
        reply("HSMSG_MANAGED_FAKEHOSTS", hi->handle);
        struct hs_manager *manager;
        for(manager = huser->managements; manager; manager = manager->unext) {
            if(manager->type == 1) {
                struct hs_toplevel *tlfh = manager->object;
                struct hs_secondlevel *slfh;
                struct hs_assignment *assignment;
                int slfhs = 0, assignments = 0;
                for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
                    slfhs++;
                    for(assignment = slfh->assignments; assignment; assignment = assignment->next)
                        assignments++;
                }
                reply("HSMSG_MANAGED_TOPLEVEL", tlfh->fakehost, slfhs, assignments);
            }
        }
        for(manager = huser->managements; manager; manager = manager->unext) {
            if(manager->type == 2) {
                struct hs_secondlevel *slfh = manager->object;
                struct hs_toplevel *tlfh = slfh->toplevel;
                //check if the user is already a manager of the tlfh
                struct hs_manager *cmanager;
                for(cmanager = tlfh->managers; cmanager; cmanager = cmanager->unext) {
                    if(cmanager->user == huser) break;
                }
                if(cmanager) continue;
                struct hs_assignment *assignment;
                int assignments = 0;
                for(assignment = slfh->assignments; assignment; assignment = assignment->next)
                    assignments++;
                reply("HSMSG_MANAGED_FAKEHOST", slfh->fakehost, tlfh->fakehost, assignments);
            }
        }
        if(huser->hi == user->handle_info)
            reply("HSMSG_MANAGE_HOWTO");
    }
    return 1;
}

static MODCMD_FUNC(cmd_addhost) {
    struct handle_info *hi;
    if (!(hi = user->handle_info)) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(argv[1], 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
        return 0;
    }
    if(!fhinfo.have_secondlevel) {
        if(!check_management_access(hi, NULL, NULL)) {
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        if(fhinfo.parse_state != HS_FHPARSE_UNKNOWN) {
            reply("HSMSG_FAKEHOST_TOPLEVEL_ALREADY_EXISTS", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        hs_add_toplevel(fhinfo.tlfh_name);
        reply("HSMSG_FAKEHOST_TOPLEVEL_ADDED", fhinfo.tlfh_name);
    } else {
        if(!fhinfo.tlfh) {
            reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        if(!check_management_access(hi, fhinfo.tlfh, NULL)) {
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        if(fhinfo.parse_state != HS_FHPARSE_UNKNOWN) {
            reply("HSMSG_FAKEHOST_SECONDLEVEL_ALREADY_EXISTS", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        hs_add_secondlevel(fhinfo.tlfh, fhinfo.slfh_name);
        reply("HSMSG_FAKEHOST_SECONDLEVEL_ADDED", fhinfo.slfh_name, fhinfo.tlfh_name);
    }
    return 1;
}

static MODCMD_FUNC(cmd_delhost) {
    struct handle_info *hi;
    if (!(hi = user->handle_info)) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(argv[1], 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    if(!fhinfo.slfh) {
        if(!check_management_access(hi, (hostserv_conf.manager_can_del_toplevel ? fhinfo.tlfh : NULL), NULL)) { /* manager access is enough to delete whole toplevel? */
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        hs_del_toplevel(fhinfo.tlfh);
        reply("HSMSG_FAKEHOST_TOPLEVEL_DELETED", fhinfo.tlfh_name);
    } else {
        if(!check_management_access(hi, fhinfo.tlfh, (hostserv_conf.manager_can_del_secondlevel ? fhinfo.slfh : NULL))) {
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        hs_del_secondlevel(fhinfo.slfh, 1);
        reply("HSMSG_FAKEHOST_SECONDLEVEL_DELETED", fhinfo.slfh_name, fhinfo.tlfh_name);
    }
    return 1;
}

static MODCMD_FUNC(cmd_renamehost) {
    struct handle_info *hi;
    if (!(hi = user->handle_info)) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    //old fakehost name
    struct hs_fakehost_info fhinfo = parse_fakehost_info(argv[1], 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    //new fakehost name
    struct hs_fakehost_info new_fhinfo = parse_fakehost_info(argv[2], 0);
    if(new_fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
        return 0;
    } else if(new_fhinfo.parse_state != HS_FHPARSE_UNKNOWN && (irccasecmp(fhinfo.tlfh_name, new_fhinfo.tlfh_name) || (new_fhinfo.slfh && irccasecmp(fhinfo.slfh_name, new_fhinfo.slfh_name)))) {
        reply("HSMSG_FAKEHOST_TOPLEVEL_ALREADY_EXISTS", new_fhinfo.slfh_name, new_fhinfo.tlfh_name);
        return 0;
    }
    
    if(!fhinfo.slfh) {
        if(!check_management_access(hi, (hostserv_conf.manager_can_rename_toplevel ? fhinfo.tlfh : NULL), NULL)) { /* manager access is enough to delete whole toplevel? */
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        if(fhinfo.have_secondlevel) {
            //can't rename toplevel into secondlevel fakehost!
            new_fhinfo.tlfh_name--;
            new_fhinfo.tlfh_name[0] = '.';
            reply("HSMSG_TOPLEVEL_INVALID", new_fhinfo.slfh_name);
            return 0;
        }
        if(strcmp(new_fhinfo.tlfh_name, fhinfo.tlfh->fakehost))
            hs_rename_toplevel(fhinfo.tlfh, new_fhinfo.tlfh_name);
        reply("HSMSG_FAKEHOST_RENAMED", fhinfo.slfh_name, fhinfo.tlfh_name, new_fhinfo.slfh_name, new_fhinfo.tlfh_name);
    } else {
        if(!check_management_access(hi, fhinfo.tlfh, (hostserv_conf.manager_can_rename_secondlevel ? fhinfo.slfh : NULL))) {
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        if(irccasecmp(new_fhinfo.tlfh_name, fhinfo.tlfh_name)) {
            //can't rename toplevel and secondlevel fakehost with one command!
            new_fhinfo.tlfh_name--;
            new_fhinfo.tlfh_name[0] = '.';
            reply("HSMSG_TOPLEVEL_INVALID", new_fhinfo.slfh_name);
            return 0;
        }
        if(strcmp(new_fhinfo.slfh_name, fhinfo.slfh->fakehost))
            hs_rename_secondlevel(fhinfo.slfh, new_fhinfo.slfh_name);
        reply("HSMSG_FAKEHOST_RENAMED", fhinfo.slfh_name, fhinfo.tlfh_name, new_fhinfo.slfh_name, new_fhinfo.tlfh_name);
    }
    return 1;
}

static MODCMD_FUNC(cmd_addmanager) {
    struct handle_info *hi;
    char *fakehost;
    if(!strchr(argv[1], '.')) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
        fakehost = argv[2];
    } else {
        if (!(hi = modcmd_get_handle_info(user, argv[2])))
            return 0;
        fakehost = argv[1];
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(fakehost, 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", fakehost);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    if(!check_management_access(user->handle_info, fhinfo.tlfh, fhinfo.slfh)) {
        reply("HSMSG_ACCESS_DENIED");
        return 0;
    }
    struct hs_user *huser = hs_get_user(hi, 1);
    struct hs_manager *manager;
    if(fhinfo.slfh) {
        for(manager = huser->managements; manager; manager = manager->next) {
            if(manager->type == 2 && manager->object == fhinfo.slfh) {
                reply("HSMSG_MANAGER_ALREADY", hi->handle, fhinfo.slfh_name, fhinfo.tlfh_name);
                return 0;
            }
        }
    }
    for(manager = huser->managements; manager; manager = manager->next) {
        if(manager->type == 1 && manager->object == fhinfo.tlfh) {
            reply("HSMSG_MANAGER_ALREADY", hi->handle, "*", fhinfo.tlfh_name);
            return 0;
        }
    }
    if(fhinfo.slfh)
        hs_add_manager_secondlevel(fhinfo.slfh, huser);
    else {
        hs_add_manager_toplevel(fhinfo.tlfh, huser);
        //remove from all slfh's
        struct hs_manager *next_manager;
        struct hs_secondlevel *slfh;
        for(manager = huser->managements; manager; manager = next_manager) {
            next_manager = manager->next;
            if(manager->type == 2) {
                slfh = manager->object;
                if(slfh->toplevel == fhinfo.tlfh)
                    hs_del_manager(manager, 1);
            }
        }
    }
    reply("HSMSG_MANAGER_ADDED", hi->handle, fhinfo.slfh_name, fhinfo.tlfh_name);
    return 1;
}

static MODCMD_FUNC(cmd_delmanager) {
    struct handle_info *hi;
    char *fakehost;
    if(!strchr(argv[1], '.')) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
        fakehost = argv[2];
    } else {
        if (!(hi = modcmd_get_handle_info(user, argv[2])))
            return 0;
        fakehost = argv[1];
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(fakehost, 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", fakehost);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    if(!check_management_access(user->handle_info, fhinfo.tlfh, fhinfo.slfh)) {
        reply("HSMSG_ACCESS_DENIED");
        return 0;
    }
    struct hs_user *huser = hs_get_user(hi, 0);
    struct hs_manager *manager;
    if(!huser) {
        reply("HSMSG_MANAGER_NOT", hi->handle, fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    if(fhinfo.slfh) {
        for(manager = huser->managements; manager; manager = manager->unext) {
            if(manager->type == 2 && manager->object == fhinfo.slfh) 
                break;
        }
        if(!manager) {
            reply("HSMSG_MANAGER_NOT", hi->handle, fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
    } else {
        for(manager = huser->managements; manager; manager = manager->unext) {
            if(manager->type == 1 && manager->object == fhinfo.tlfh) 
                break;
        }
        if(!manager) {
            reply("HSMSG_MANAGER_NOT", hi->handle, "*", fhinfo.tlfh_name);
            return 0;
        }
    }
    hs_del_manager(manager, 1);
    reply("HSMSG_MANAGER_DELETED", hi->handle, fhinfo.slfh_name, fhinfo.tlfh_name);
    return 1;
}

static MODCMD_FUNC(cmd_set) {
    struct handle_info *hi;
    struct hs_user *hs_user;
    struct hs_assignment *assignment;
    struct hs_toplevel *tlfh;
    struct hs_secondlevel *slfh;
    
    if (!(hi = user->handle_info)) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    hs_user = hs_get_user(hi, 0);
    if(!hs_user)
        return 0; //nothing to do here
    if(!strcmp(argv[1], "*")) {
        hs_activate_assignment(hs_user, NULL);
        return 1;
    } else {
        struct hs_fakehost_info fhinfo = parse_fakehost_info(argv[1], 1);
        if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
            reply("HSMSG_TOPLEVEL_INVALID", argv[1]);
            return 0;
        } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN) {
            reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        for(assignment = hs_user->assignments; assignment; assignment = assignment->unext) {
            slfh = assignment->secondlevel;
            tlfh = slfh->toplevel;
            if(tlfh == fhinfo.tlfh && slfh == fhinfo.slfh) {
                hs_activate_assignment(hs_user, assignment);
                reply("HSMSG_FAKEHOST_SET_SUCCESS", slfh->fakehost, tlfh->fakehost);
                return 1;
            }
        }
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
}

static MODCMD_FUNC(cmd_assign) {
    struct handle_info *hi;
    char *fakehost;
    if(!strchr(argv[1], '.')) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
        fakehost = argv[2];
    } else {
        if (!(hi = modcmd_get_handle_info(user, argv[2])))
            return 0;
        fakehost = argv[1];
    }
    if (!user->handle_info) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(fakehost, 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", fakehost);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN || !fhinfo.slfh) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    struct hs_user *hs_user = hs_get_user(hi, 1);
    if(!check_management_access(user->handle_info, fhinfo.tlfh, fhinfo.slfh)) {
        reply("HSMSG_ACCESS_DENIED");
        return 0;
    }
    if(hs_get_assignment(fhinfo.slfh, hs_user)) {
        reply("HSMSG_FAKEHOST_ASSIGNED", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    hs_add_assignment(fhinfo.slfh, hs_user, HS_ASSIGNMENTSTATE_AUTO);
    reply("HSMSG_FAKEHOST_ASSIGN_SUCCESS", fhinfo.slfh_name, fhinfo.tlfh_name);
    return 1;
}

static MODCMD_FUNC(cmd_unassign) {
    struct handle_info *hi;
    char *fakehost;
    if(!strchr(argv[1], '.')) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
        fakehost = argv[2];
    } else {
        if (!(hi = modcmd_get_handle_info(user, argv[2])))
            return 0;
        fakehost = argv[1];
    }
    if (!user->handle_info) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    struct hs_fakehost_info fhinfo = parse_fakehost_info(fakehost, 1);
    if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
        reply("HSMSG_TOPLEVEL_INVALID", fakehost);
        return 0;
    } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN || !fhinfo.slfh) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    struct hs_assignment *assignment;
    struct hs_user *hs_user = hs_get_user(hi, 0);
    if(!hs_user) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    if(!check_management_access(user->handle_info, fhinfo.tlfh, fhinfo.slfh)) {
        reply("HSMSG_ACCESS_DENIED");
        return 0;
    }
    if(!(assignment = hs_get_assignment(fhinfo.slfh, hs_user))) {
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
    hs_del_assignment(assignment, 1);
    reply("HSMSG_FAKEHOST_UNASSIGN_SUCCESS", fhinfo.slfh_name, fhinfo.tlfh_name);
    return 1;
}

static MODCMD_FUNC(cmd_oset) {
    struct handle_info *hi;
    char *fakehost;
    struct hs_assignment *assignment;
    if(!strchr(argv[1], '.') && strcmp(argv[1], "*")) {
        if (!(hi = modcmd_get_handle_info(user, argv[1])))
            return 0;
        fakehost = argv[2];
    } else {
        if (!(hi = modcmd_get_handle_info(user, argv[2])))
            return 0;
        fakehost = argv[1];
    }
    if (!user->handle_info) {
        reply("NSMSG_MUST_AUTH");
        return 0;
    }
    struct hs_user *hs_user = hs_get_user(hi, 1);
    for(assignment = hs_user->assignments; assignment; assignment = assignment->unext) {
        if(assignment->active)
            break;
    }
    if(assignment && !check_management_access(user->handle_info, (hostserv_conf.manager_toplevel_can_oset ? assignment->secondlevel->toplevel : NULL), (hostserv_conf.manager_secondlevel_can_oset ? assignment->secondlevel : NULL))) {
        reply("HSMSG_ACCESS_DENIED");
        return 0;
    }
    if(!strcmp(fakehost, "*")) {
        if(!assignment)
            return 0; //simply ignore (there is no assignment in use)
        hs_activate_assignment(hs_user, NULL);
        return 1;
    } else {
        struct hs_fakehost_info fhinfo = parse_fakehost_info(fakehost, 1);
        if(fhinfo.parse_state == HS_FHPARSE_INVALID) {
            reply("HSMSG_TOPLEVEL_INVALID", fakehost);
            return 0;
        } else if(fhinfo.parse_state == HS_FHPARSE_UNKNOWN || !fhinfo.slfh) {
            reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
            return 0;
        }
        if(!check_management_access(user->handle_info, (hostserv_conf.manager_toplevel_can_oset ? fhinfo.tlfh : NULL), (hostserv_conf.manager_secondlevel_can_oset ? fhinfo.slfh : NULL))) {
            reply("HSMSG_ACCESS_DENIED");
            return 0;
        }
        struct hs_toplevel *tlfh;
        struct hs_secondlevel *slfh;
        for(assignment = hs_user->assignments; assignment; assignment = assignment->unext) {
            slfh = assignment->secondlevel;
            tlfh = slfh->toplevel;
            if(tlfh == fhinfo.tlfh && slfh == fhinfo.slfh) {
                hs_activate_assignment(hs_user, assignment);
                reply("HSMSG_FAKEHOST_SET_SUCCESS", slfh->fakehost, tlfh->fakehost);
                return 1;
            }
        }
        reply("HSMSG_UNKNOWN_FAKEHOST", fhinfo.slfh_name, fhinfo.tlfh_name);
        return 0;
    }
}

static void hostserv_conf_read(void) {
    dict_t conf_node;
    const char *str;

    str = "modules/hostserv";
    if (!(conf_node = conf_get_data(str, RECDB_OBJECT))) {
        log_module(HS_LOG, LOG_ERROR, "config node `%s' is missing or has wrong type.", str);
        return;
    }

    str = database_get_data(conf_node, "nick", RECDB_QSTRING);
    if(hostserv_conf.nick && strcmp(hostserv_conf.nick, str)) {
        //nick changed
    }
    hostserv_conf.nick = str;
    
    str = database_get_data(conf_node, "modes", RECDB_QSTRING);
    hostserv_conf.modes = (str ? str : NULL);
    
    str = database_get_data(conf_node, "toplevel_access", RECDB_QSTRING);
    unsigned int toplevel_access = (str ? atoi(str) : 0);
    hostserv_conf.toplevel_access = (toplevel_access ? toplevel_access : 600);
    
    str = database_get_data(conf_node, "fallback_other_assignment", RECDB_QSTRING);
    hostserv_conf.fallback_other_assignment = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_can_del_toplevel", RECDB_QSTRING);
    hostserv_conf.manager_can_del_toplevel = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_can_del_secondlevel", RECDB_QSTRING);
    hostserv_conf.manager_can_del_secondlevel = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_can_rename_toplevel", RECDB_QSTRING);
    hostserv_conf.manager_can_rename_toplevel = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_can_rename_secondlevel", RECDB_QSTRING);
    hostserv_conf.manager_can_rename_secondlevel = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_toplevel_can_oset", RECDB_QSTRING);
    hostserv_conf.manager_toplevel_can_oset = (str && atoi(str) ? 1 : 0);
    
    str = database_get_data(conf_node, "manager_secondlevel_can_oset", RECDB_QSTRING);
    hostserv_conf.manager_secondlevel_can_oset = (str && atoi(str) ? 1 : 0);
}

static int hostserv_saxdb_read_secondlevel(const char *name, void *data, UNUSED_ARG(void *extra));
static int hostserv_saxdb_read_assignments(const char *name, void *data, UNUSED_ARG(void *extra));

static int hostserv_saxdb_read_toplevel(const char *name, void *data, UNUSED_ARG(void *extra)) {
    struct record_data *rd = data;
    struct hs_toplevel *tlfh;
    struct hs_manager *managerTL;
    struct hs_user *user;
    struct dict *object;

     if (rd->type == RECDB_OBJECT) {
        dict_t db = GET_RECORD_OBJECT(rd);
        dict_iterator_t it;
        
        tlfh = hs_add_toplevel(name);
        
        if ((object = database_get_data(db, KEY_MANAGERS, RECDB_OBJECT))) {
            for (it = dict_first(object); it; it = iter_next(it)) {
                user = hs_get_user(get_handle_info(iter_key(it)), 1);
                //rd = iter_data(it);
                /* nothing in here, yet */
                managerTL = hs_add_manager_toplevel(tlfh, user);
                if (database_get_data(db, KEY_ACTIVE, RECDB_QSTRING))
                    managerTL->active = 1;
                else
                    managerTL->active = 0;
            }
        }
        
        if ((object = database_get_data(db, KEY_SECONDLEVEL, RECDB_OBJECT)))
            dict_foreach(object, hostserv_saxdb_read_secondlevel, tlfh);
    }
    return 0;
}

static int hostserv_saxdb_read_secondlevel(const char *name, void *data, UNUSED_ARG(void *extra)) {
    struct record_data *rd = data;
    struct hs_toplevel *tlfh = extra;
    struct hs_secondlevel *slfh;
    struct hs_manager *managerSL;
    struct hs_user *user;
    struct dict *object;

    if (rd->type == RECDB_OBJECT) {
        dict_t db = GET_RECORD_OBJECT(rd);
        dict_iterator_t it;
        
        slfh = hs_add_secondlevel(tlfh, name);
        
        if ((object = database_get_data(db, KEY_MANAGERS, RECDB_OBJECT))) {
            for (it = dict_first(object); it; it = iter_next(it)) {
                user = hs_get_user(get_handle_info(iter_key(it)), 1);
                //rd = iter_data(it);
                /* nothing in here, yet */
                managerSL = hs_add_manager_secondlevel(slfh, user);
                if (database_get_data(db, KEY_ACTIVE, RECDB_QSTRING))
                    managerSL->active = 1;
                else
                    managerSL->active = 0;
            }
        }
        
        if ((object = database_get_data(db, KEY_ASSIGNMENTS, RECDB_OBJECT)))
            dict_foreach(object, hostserv_saxdb_read_assignments, slfh);
    }
    return 0;
}

static int hostserv_saxdb_read_assignments(const char *name, void *data, UNUSED_ARG(void *extra)) {
    struct record_data *rd = data;
    struct hs_secondlevel *slfh = extra;
    struct hs_user *user;
    int active;
    
    if (rd->type == RECDB_OBJECT) {
        dict_t db = GET_RECORD_OBJECT(rd);
        
        user = hs_get_user(get_handle_info(name), 1);
        active = (database_get_data(db, KEY_ACTIVE, RECDB_QSTRING) ? HS_ASSIGNMENTSTATE_ON : HS_ASSIGNMENTSTATE_OFF);
        
        hs_add_assignment(slfh, user, active);
    }
    
    return 0;
}

static int
hostserv_saxdb_read(struct dict *db)
{
    struct dict *object;

    if ((object = database_get_data(db, KEY_TOPLEVEL, RECDB_OBJECT)))
        dict_foreach(object, hostserv_saxdb_read_toplevel, NULL);

    return 1;
}

static int
hostserv_saxdb_write(struct saxdb_context *ctx)
{
    struct hs_toplevel *tlfh;
    struct hs_secondlevel *slfh;
    struct hs_assignment *assng;
    struct hs_manager *manager;

    saxdb_start_record(ctx, KEY_TOPLEVEL, 1);
    for(tlfh = toplevels; tlfh; tlfh = tlfh->next) {
        saxdb_start_record(ctx, tlfh->fakehost, 1);
        
        saxdb_start_record(ctx, KEY_MANAGERS, 1);
        for(manager = tlfh->managers; manager; manager = manager->next) {
            saxdb_start_record(ctx, manager->user->hi->handle, 0);
            //additional manager information?
            if(manager->active)
                saxdb_write_int(ctx, KEY_ACTIVE, manager->active);
            saxdb_end_record(ctx);
        }
        saxdb_end_record(ctx);
        
        saxdb_start_record(ctx, KEY_SECONDLEVEL, 1);
        for(slfh = tlfh->secondlevel; slfh; slfh = slfh->next) {
            saxdb_start_record(ctx, slfh->fakehost, 1);
            
            saxdb_start_record(ctx, KEY_MANAGERS, 1);
            for(manager = slfh->managers; manager; manager = manager->next) {
                saxdb_start_record(ctx, manager->user->hi->handle, 0);
                //additional manager information?
                if(manager->active)
                    saxdb_write_int(ctx, KEY_ACTIVE, manager->active);
                saxdb_end_record(ctx);
            }
            saxdb_end_record(ctx);
            
            saxdb_start_record(ctx, KEY_ASSIGNMENTS, 1);
            for(assng = slfh->assignments; assng; assng = assng->next) {
                saxdb_start_record(ctx, assng->user->hi->handle, 0);
                //additional assignment information?
                if(assng->active)
                    saxdb_write_int(ctx, KEY_ACTIVE, assng->active);
                saxdb_end_record(ctx);
            }
            saxdb_end_record(ctx);
            
            saxdb_end_record(ctx);
        }
        saxdb_end_record(ctx);
        
        saxdb_end_record(ctx);
    }
    saxdb_end_record(ctx);
    
    return 0;
}


static void hostserv_db_cleanup(void) {
    hs_free_all();
}

int hostserv_init() {
    HS_LOG = log_register_type("HostServ", "file:hostserv.log");
    
    const char *nick, *modes;
    if((nick = conf_get_data("modules/hostserv/nick", RECDB_QSTRING))) {
        modes = conf_get_data("modules/hostserv/modes", RECDB_QSTRING);
        hostserv = AddLocalUser(nick, nick, NULL, "Host Service", modes);
        hostserv_service = service_register(hostserv);
        hostserv_service->trigger = '*';
    }
        
    conf_register_reload(hostserv_conf_read);
    reg_exit_func(hostserv_db_cleanup);
    saxdb_register("HostServ", hostserv_saxdb_read, hostserv_saxdb_write);
    hostserv_module = module_register("HostServ", HS_LOG, "mod-hostserv.help", NULL);
    modcmd_register(hostserv_module, "view", cmd_view, 0, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "addmanager", cmd_addmanager, 3, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "delmanager", cmd_delmanager, 3, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "set", cmd_set, 2, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "assign", cmd_assign, 3, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "unassign", cmd_unassign, 3, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "addhost", cmd_addhost, 2, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "delhost", cmd_delhost, 2, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "renamehost", cmd_renamehost, 3, MODCMD_REQUIRE_AUTHED, NULL);
    modcmd_register(hostserv_module, "oset", cmd_oset, 3, MODCMD_REQUIRE_AUTHED, NULL);
    message_register_table(msgtab);
    return 1;
}

int hostserv_finalize(void) {
    dict_t conf_node;
    const char *str;

    str = "modules/hostserv";
    if (!(conf_node = conf_get_data(str, RECDB_OBJECT))) {
        log_module(HS_LOG, LOG_ERROR, "config node `%s' is missing or has wrong type.", str);
        return 0;
    }

    str = database_get_data(conf_node, "nick", RECDB_QSTRING);
    if (str) hostserv_conf.nick = str;
    
    str = database_get_data(conf_node, "modes", RECDB_QSTRING);
    if (str) hostserv_conf.modes = str; 
    return 1;
}