const char git_version[] = "git-652-0167bfd";
