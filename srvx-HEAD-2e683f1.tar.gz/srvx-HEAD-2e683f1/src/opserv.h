/* opserv.h - IRC Operator assistant service
 * Copyright 2000-2004 srvx Development Team
 *
 * This file is part of srvx.
 *
 * srvx is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with srvx; if not, write to the Free Software Foundation,
 * Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA.
 */

#ifndef _opserv_h
#define _opserv_h

/* DEVNULL_MODE_* go into devnull_class.modes */
#define DEVNULL_MODE_A 0x00000001
#define DEVNULL_MODE_B 0x00000002
#define DEVNULL_MODE_C 0x00000004
#define DEVNULL_MODE_D 0x00000008
#define DEVNULL_MODE_E 0x00000010
#define DEVNULL_MODE_F 0x00000020
#define DEVNULL_MODE_G 0x00000040
#define DEVNULL_MODE_H 0x00000080
#define DEVNULL_MODE_I 0x00000100
#define DEVNULL_MODE_J 0x00000200
#define DEVNULL_MODE_K 0x00000400
#define DEVNULL_MODE_L 0x00000800
#define DEVNULL_MODE_M 0x00001000
#define DEVNULL_MODE_N 0x00002000
#define DEVNULL_MODE_OPME 0x00004000

#define DEVNULL_MODES "abcdefghijklmno"

#define DEVNULL_FLAGGED(hi, tok) ((hi)->modes & DEVNULL_##tok)
#define DEVNULL_SET_FLAG(hi, tok) ((hi)->modes |= DEVNULL_##tok)
#define DEVNULL_CLEAR_FLAG(hi, tok) ((hi)->modes &= ~DEVNULL_##tok)

struct devnull_class {
    char *name;
    unsigned long modes;
    unsigned long maxchan;
    unsigned long maxsendq;
};

void init_opserv(const char *nick);
unsigned int gag_create(const char *mask, const char *owner, const char *reason, unsigned long expires);
int opserv_bad_channel(const char *name);
void devnull_delete(const char *auth);
void devnull_rename(const char *oldauth, const char *newauth);
int devnull_check(const char *name);
struct devnull_class* devnull_get(const char *name);
struct userNode* GetOpServ(void);
void operpart(struct chanNode *chan, struct userNode *user);
void operadd(struct userNode *user);
void operdel(struct userNode *user);

#endif
